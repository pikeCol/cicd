import { Link } from 'react-router-dom';

const Dashboard: React.FC = () => {
    return(
        <Link to="/dashboard">
        <h1>Dashboard</h1>
        </Link>
    );

}

export default Dashboard;